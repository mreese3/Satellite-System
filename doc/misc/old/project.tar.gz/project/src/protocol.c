#define MTU 255 //MTU of modems is 255 bytes. Best to only tansmist 254 then.

//Packed struct containing a bitfield for all flags
//1 bit per flag
struct flagfield {
	unsigned int flag1: 1;
	unsigned int flag2: 1;
	unsigned int flag3: 1;
	unsigned int flag4: 1;
	unsigned int flag5: 1;
	unsigned int flag6: 1;
	unsigned int flag7: 1;
	unsigned int flag8: 1;
	};

struct standardpacket {
	const	 char	preamble;	// Byte: Preamble (Magic Number)
	struct flagfield flags;		// Byte: Struct containing 8 flag bits
	unsigned short	sourceaddr; 	// 2Bytes: Source Address 
	unsigned short	destaddr; 	// 2Bytes: Destination Address 
	unsigned short	sensorid;	// 2Bytes: Sensor Number 
	unsigned char 	length; 	// Byte: Length of Payload section
	char*		payload;	// Payload of length (MTU - 12)
	unsigned char	checksum;	// Byte: CRC against header and payload
	const	 char	endpacket; 	// Byte: End of Data
	};

struct unidirectionalpacket {
	const	 char	preamble; 	// Byte: Preamble (Magic Number)
	struct flagfield flags;		// Byte: Struct containing 8 flag bits
	unsigned short	sensorid;	// 2Bytes: Sensor Number 
	unsigned char	length; 	// Byte: Length of Payload section
	char*		payload;	// Payload of length (MTU - 8)
	unsigned char	checksum;	// Byte: CRC against header and payload
	const	 char	endpacket; 	// Byte: End of Data
	};
